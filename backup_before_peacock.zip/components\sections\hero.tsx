"use client"

import { useEffect, useRef } from "react"
import { gsap } from "gsap"
import { HeroScene } from "@/components/hero-scene"
import { MagneticButton } from "@/components/magnetic-button"
import { ArrowDown, Github, Linkedin } from "lucide-react"

export function Hero() {
  const tagRef = useRef<HTMLSpanElement>(null)
  const nameRef = useRef<HTMLHeadingElement>(null)
  const subtitleRef = useRef<HTMLParagraphElement>(null)
  const ctaRef = useRef<HTMLDivElement>(null)
  const scrollRef = useRef<HTMLDivElement>(null)
  const linksRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const tl = gsap.timeline({ defaults: { ease: "power3.out" } })

    tl.fromTo(tagRef.current, { opacity: 0, y: 20 }, { opacity: 1, y: 0, duration: 0.7, delay: 0.4 })
      .fromTo(nameRef.current, { opacity: 0, y: 60, skewY: 3 }, { opacity: 1, y: 0, skewY: 0, duration: 1.1 }, "-=0.3")
      .fromTo(subtitleRef.current, { opacity: 0, y: 30 }, { opacity: 1, y: 0, duration: 0.9 }, "-=0.5")
      .fromTo(ctaRef.current, { opacity: 0, y: 24 }, { opacity: 1, y: 0, duration: 0.7 }, "-=0.4")
      .fromTo(linksRef.current, { opacity: 0, y: 16 }, { opacity: 1, y: 0, duration: 0.6 }, "-=0.3")
      .fromTo(scrollRef.current, { opacity: 0 }, { opacity: 1, duration: 0.5 }, "-=0.2")
  }, [])

  const scrollTo = (id: string) => {
    const el = document.getElementById(id)
    if (el) el.scrollIntoView({ behavior: "smooth" })
  }

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* 3D Canvas */}
      <HeroScene />

      {/* Radial gradient overlay for text readability */}
      <div
        className="absolute inset-0 z-1 pointer-events-none"
        style={{
          background:
            "radial-gradient(ellipse 70% 60% at 50% 50%, transparent 30%, #0a0814cc 80%, #0a0814 100%)",
        }}
      />

      {/* Content */}
      <div className="relative z-10 text-center px-6 max-w-5xl mx-auto">
        {/* Tag line */}
        <span
          ref={tagRef}
          className="inline-flex items-center gap-2 mb-6 px-4 py-1.5 rounded-full text-xs font-mono tracking-widest uppercase opacity-0"
          style={{
            background: "oklch(0.72 0.22 280 / 0.12)",
            border: "1px solid oklch(0.72 0.22 280 / 0.35)",
            color: "oklch(0.85 0.15 280)",
          }}
        >
          <span
            className="w-1.5 h-1.5 rounded-full animate-pulse"
            style={{ background: "oklch(0.72 0.22 280)" }}
          />
          Available for opportunities
        </span>

        {/* Name */}
        <h1 ref={nameRef} className="text-6xl md:text-8xl lg:text-9xl font-bold tracking-tighter mb-5 opacity-0 leading-none">
          <span className="block text-foreground">Adarsh</span>
          <span className="block gradient-text">Maurya</span>
        </h1>

        {/* Subtitle */}
        <p
          ref={subtitleRef}
          className="text-base md:text-xl text-muted-foreground max-w-2xl mx-auto mb-8 leading-relaxed opacity-0"
        >
          Full-Stack & AI Developer · IIIT Bhopal · Building{" "}
          <span style={{ color: "oklch(0.80 0.18 280)" }}>scalable products</span> that solve real problems
        </p>

        {/* CTA buttons */}
        <div
          ref={ctaRef}
          className="flex flex-col sm:flex-row gap-4 justify-center items-center opacity-0 mb-8"
        >
          <MagneticButton>
            <button
              onClick={() => scrollTo("projects")}
              className="btn-primary px-8 py-4 text-base font-semibold"
            >
              View Projects
            </button>
          </MagneticButton>

          <MagneticButton>
            <button
              onClick={() => scrollTo("contact")}
              className="btn-outline px-8 py-4 text-base font-medium"
            >
              Get in Touch
            </button>
          </MagneticButton>
        </div>

        {/* Social quick links */}
        <div ref={linksRef} className="flex items-center justify-center gap-5 opacity-0">
          <a
            href="https://github.com/adarsh062"
            target="_blank"
            rel="noopener noreferrer"
            className="p-2.5 rounded-full transition-all duration-300 hover:scale-110"
            style={{
              background: "oklch(0.14 0.012 268 / 0.8)",
              border: "1px solid oklch(0.25 0.015 268 / 0.5)",
              color: "oklch(0.75 0.010 268)",
            }}
            aria-label="GitHub"
          >
            <Github className="w-4 h-4" />
          </a>
          <a
            href="https://www.linkedin.com/in/adarsh-maurya-64077629/"
            target="_blank"
            rel="noopener noreferrer"
            className="p-2.5 rounded-full transition-all duration-300 hover:scale-110"
            style={{
              background: "oklch(0.14 0.012 268 / 0.8)",
              border: "1px solid oklch(0.25 0.015 268 / 0.5)",
              color: "oklch(0.75 0.010 268)",
            }}
            aria-label="LinkedIn"
          >
            <Linkedin className="w-4 h-4" />
          </a>
          <span
            className="text-xs font-mono tracking-widest"
            style={{ color: "oklch(0.45 0.008 268)" }}
          >
            mauryadarsh9140@gmail.com
          </span>
        </div>
      </div>

      {/* Scroll indicator */}
      <div
        ref={scrollRef}
        className="absolute bottom-8 left-1/2 -translate-x-1/2 z-10 opacity-0 flex flex-col items-center gap-2 cursor-pointer"
        onClick={() => scrollTo("about")}
      >
        <span
          className="text-xs font-mono tracking-widest uppercase"
          style={{ color: "oklch(0.45 0.008 268)" }}
        >
          scroll
        </span>
        <div
          className="w-px h-10 relative overflow-hidden"
          style={{ background: "oklch(0.72 0.22 280 / 0.2)" }}
        >
          <div
            className="absolute top-0 left-0 w-full"
            style={{
              height: "50%",
              background: "oklch(0.72 0.22 280)",
              animation: "float 1.5s ease-in-out infinite",
            }}
          />
        </div>
      </div>
    </section>
  )
}
