"use client"

import { useRef, useMemo, useState, useEffect } from "react"
import { Canvas, useFrame, useThree } from "@react-three/fiber"
import { Points, PointMaterial, Sphere } from "@react-three/drei"
import * as THREE from "three"

/* ── Utility: random sphere point ─────────────────────── */
function randSphere(count: number, rMin: number, rMax: number) {
  const pos = new Float32Array(count * 3)
  for (let i = 0; i < count; i++) {
    const r = rMin + Math.random() * (rMax - rMin)
    const theta = Math.random() * Math.PI * 2
    const phi = Math.acos(2 * Math.random() - 1)
    pos[i * 3] = r * Math.sin(phi) * Math.cos(theta)
    pos[i * 3 + 1] = r * Math.sin(phi) * Math.sin(theta)
    pos[i * 3 + 2] = r * Math.cos(phi)
  }
  return pos
}

/* ── Outer particle field ─────────────────────────────── */
function ParticleField({ mouse }: { mouse: React.RefObject<{ x: number; y: number }> }) {
  const ref = useRef<THREE.Points>(null)
  const positions = useMemo(() => randSphere(2400, 2.8, 5.5), [])

  useFrame((state) => {
    if (!ref.current) return
    const t = state.clock.getElapsedTime()
    ref.current.rotation.y = t * 0.04
    ref.current.rotation.x = Math.sin(t * 0.025) * 0.12
    if (mouse.current) {
      ref.current.rotation.y += mouse.current.x * 0.00025
      ref.current.rotation.x += mouse.current.y * 0.00025
    }
  })

  return (
    <Points ref={ref} positions={positions} stride={3} frustumCulled={false}>
      <PointMaterial
        transparent
        color="#a78bfa"
        size={0.014}
        sizeAttenuation
        depthWrite={false}
        opacity={0.75}
      />
    </Points>
  )
}

/* ── Inner ring particles ─────────────────────────────── */
function InnerParticles({ mouse }: { mouse: React.RefObject<{ x: number; y: number }> }) {
  const ref = useRef<THREE.Points>(null)
  const positions = useMemo(() => randSphere(800, 1.4, 2.2), [])

  useFrame((state) => {
    if (!ref.current) return
    const t = state.clock.getElapsedTime()
    ref.current.rotation.y = -t * 0.08
    ref.current.rotation.z = t * 0.05
    if (mouse.current) {
      ref.current.rotation.x -= mouse.current.y * 0.0003
    }
  })

  return (
    <Points ref={ref} positions={positions} stride={3} frustumCulled={false}>
      <PointMaterial
        transparent
        color="#c084fc"
        size={0.018}
        sizeAttenuation
        depthWrite={false}
        opacity={0.55}
      />
    </Points>
  )
}

/* ── Central icosahedron (wireframe + emissive core) ──── */
function CoreObject({ mouse }: { mouse: React.RefObject<{ x: number; y: number }> }) {
  const outerRef = useRef<THREE.Mesh>(null)
  const innerRef = useRef<THREE.Mesh>(null)
  const glowRef = useRef<THREE.Mesh>(null)

  useFrame((state) => {
    const t = state.clock.getElapsedTime()

    if (outerRef.current) {
      outerRef.current.position.y = Math.sin(t * 0.5) * 0.18
      outerRef.current.rotation.x = t * 0.12
      outerRef.current.rotation.z = t * 0.08
      if (mouse.current) {
        outerRef.current.rotation.y += mouse.current.x * 0.00018
        outerRef.current.rotation.x += mouse.current.y * 0.00018
      }
    }

    if (innerRef.current) {
      innerRef.current.position.y = outerRef.current?.position.y ?? 0
      innerRef.current.rotation.x = -t * 0.2
      innerRef.current.rotation.y = t * 0.15
    }

    if (glowRef.current) {
      glowRef.current.position.y = outerRef.current?.position.y ?? 0
      const s = 0.85 + Math.sin(t * 0.9) * 0.06
      glowRef.current.scale.set(s, s, s)
    }
  })

  return (
    <group>
      {/* Soft glow sphere behind */}
      <mesh ref={glowRef}>
        <sphereGeometry args={[0.9, 32, 32]} />
        <meshBasicMaterial color="#7c3aed" transparent opacity={0.08} />
      </mesh>

      {/* Core emissive sphere */}
      <mesh ref={innerRef}>
        <icosahedronGeometry args={[0.7, 2]} />
        <meshStandardMaterial
          color="#7c3aed"
          emissive="#5b21b6"
          emissiveIntensity={1.8}
          roughness={0.1}
          metalness={0.8}
          transparent
          opacity={0.9}
        />
      </mesh>

      {/* Outer wireframe shell */}
      <mesh ref={outerRef}>
        <icosahedronGeometry args={[1.3, 1]} />
        <meshBasicMaterial
          color="#a78bfa"
          wireframe
          transparent
          opacity={0.28}
        />
      </mesh>
    </group>
  )
}

/* ── Ambient ring (torus) ─────────────────────────────── */
function AmbientRing() {
  const ref = useRef<THREE.Mesh>(null)

  useFrame((state) => {
    if (!ref.current) return
    const t = state.clock.getElapsedTime()
    ref.current.rotation.x = t * 0.06
    ref.current.rotation.z = t * 0.04
  })

  return (
    <mesh ref={ref} rotation={[Math.PI / 2, 0, 0]}>
      <torusGeometry args={[1.9, 0.006, 16, 120]} />
      <meshBasicMaterial color="#a78bfa" transparent opacity={0.35} />
    </mesh>
  )
}

/* ── Camera subtle drift on mouse ─────────────────────── */
function CameraController({ mouse }: { mouse: React.RefObject<{ x: number; y: number }> }) {
  const { camera } = useThree()

  useFrame(() => {
    if (!mouse.current) return
    camera.position.x += (mouse.current.x * 0.0012 - camera.position.x) * 0.04
    camera.position.y += (-mouse.current.y * 0.0012 - camera.position.y) * 0.04
    camera.lookAt(0, 0, 0)
  })

  return null
}

/* ── Exported scene wrapper ───────────────────────────── */
export function HeroScene() {
  const mouseRef = useRef<{ x: number; y: number }>({ x: 0, y: 0 })

  const handleMouseMove = (e: React.MouseEvent) => {
    mouseRef.current.x = e.clientX - window.innerWidth / 2
    mouseRef.current.y = e.clientY - window.innerHeight / 2
  }

  return (
    <div className="absolute inset-0 z-0" onMouseMove={handleMouseMove}>
      <Canvas
        camera={{ position: [0, 0, 5.5], fov: 55 }}
        dpr={[1, 1.5]}
        gl={{ antialias: true, alpha: true, powerPreference: "high-performance" }}
      >
        <color attach="background" args={["#0a0814"]} />
        <fog attach="fog" args={["#0a0814", 8, 18]} />

        <ambientLight intensity={0.3} />
        <pointLight position={[4, 4, 4]} intensity={2.5} color="#a78bfa" />
        <pointLight position={[-4, -2, -4]} intensity={1.2} color="#7c3aed" />
        <pointLight position={[0, 6, -2]} intensity={0.8} color="#c084fc" />

        <CameraController mouse={mouseRef} />
        <ParticleField mouse={mouseRef} />
        <InnerParticles mouse={mouseRef} />
        <CoreObject mouse={mouseRef} />
        <AmbientRing />
      </Canvas>
    </div>
  )
}
